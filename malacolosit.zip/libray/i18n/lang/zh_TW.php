<?php

class Lang_zh_TW
{
    public function name()
    {
        return "繁體中文";
    }

    public function translated()
    {
        return array(
            '首页' => ''
        );
    }

    function dateFormat()
    {
        return "Y 年 m 月 d 日";
    }
}
