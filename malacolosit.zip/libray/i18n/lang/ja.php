<?php

class Lang_ja
{
  public function name()
  {
    return "日本語";
  }

  public function translated()
  {
    return array();
  }

  public function dateFormat()
  {
    return "Y 年 m 月 d 日";
  }
}
